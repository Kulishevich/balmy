import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest) {
  const url = req.nextUrl;
  const decodedPath = decodeURIComponent(url.pathname);

  let updatedPath = decodedPath
    .replace("Бренды", "brands")
    .replace("Для бороды", "dlya-borody")
    .replace("Для бритья", "dlya-britya")
    .replace("Для волос и тела", "dlya-volos-i-tela")
    .replace("Наборы", "nabory")
    .replace("Аксессуары", "aksecsuary")
    .replace("Аксеcсуары", "aksecsuary")
    .replace("Скидки", "discounts");

  const pathSegments = updatedPath.split("/");

  if (pathSegments.length > 3) {
    const subcategoryIndex = 3;
    pathSegments[subcategoryIndex] = pathSegments[subcategoryIndex]
      .toLowerCase()
      .replace(/\s+/g, "-")
      .replace(/[!]/g, "");
  }

  updatedPath = pathSegments.join("/");

  if (decodedPath !== updatedPath) {
    const redirectUrl = new URL(updatedPath, req.nextUrl.origin);
    return NextResponse.redirect(redirectUrl, 308);
  }

  return NextResponse.next();
}

export const config = {
  matcher: "/catalog/:path*",
};

// app/middleware.ts
// import { NextResponse } from "next/server";
// import type { NextRequest } from "next/server";

// const PUBLIC_PATHS = ["/authorization"];

// export function middleware(request: NextRequest) {
//   const token = request.cookies.get("token")?.value; // или другой ключ

//   const isAuthPage = PUBLIC_PATHS.includes(request.nextUrl.pathname);
//   const isAuthenticated = Boolean(token);

//   if (!isAuthenticated && !isAuthPage) {
//     return NextResponse.redirect(new URL("/authorization", request.url));
//   }

//   if (isAuthenticated && isAuthPage) {
//     return NextResponse.redirect(new URL("/", request.url));
//   }

//   return NextResponse.next();
// }
