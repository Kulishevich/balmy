(()=>{var t={};t.id=961,t.ids=[961],t.modules={10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:t=>{"use strict";t.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},33873:t=>{"use strict";t.exports=require("path")},68104:(t,n,o)=>{"use strict";o.d(n,{A:()=>f});var e,i=o(49504);function s(){return(s=Object.assign?Object.assign.bind():function(t){for(var n=1;n<arguments.length;n++){var o=arguments[n];for(var e in o)({}).hasOwnProperty.call(o,e)&&(t[e]=o[e])}return t}).apply(null,arguments)}let f=function(t){return i.createElement("svg",s({xmlns:"http://www.w3.org/2000/svg",width:33,height:32,fill:"none"},t),e||(e=i.createElement("path",{stroke:"#CFA045",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5.834 16h21.333m0 0-5.333-5.333M27.167 16l-5.333 5.334"})))}},61646:(t,n,o)=>{"use strict";o.r(n),o.d(n,{GlobalError:()=>f.a,__next_app__:()=>y,pages:()=>r,routeModule:()=>m,tree:()=>p});var e=o(45887),i=o(68432),s=o(91490),f=o.n(s),l=o(45989),a={};for(let t in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(t)&&(a[t]=()=>l[t]);o.d(n,a);let p=["",{children:["(main)",{children:["privacy-policy",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(o.bind(o,68035)),"E:\\Work\\new-balmy\\app\\(main)\\privacy-policy\\page.tsx"]}]},{layout:[()=>Promise.resolve().then(o.bind(o,10938)),"E:\\Work\\new-balmy\\app\\(main)\\privacy-policy\\layout.tsx"]}]},{layout:[()=>Promise.resolve().then(o.bind(o,5730)),"E:\\Work\\new-balmy\\app\\(main)\\layout.tsx"]}]},{layout:[()=>Promise.resolve().then(o.bind(o,27540)),"E:\\Work\\new-balmy\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(o.bind(o,2247)),"E:\\Work\\new-balmy\\app\\not-found.tsx"]}],r=["E:\\Work\\new-balmy\\app\\(main)\\privacy-policy\\page.tsx"],y={require:o,loadChunk:()=>Promise.resolve()},m=new e.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/(main)/privacy-policy/page",pathname:"/privacy-policy",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:p}})},79752:(t,n,o)=>{Promise.resolve().then(o.bind(o,1908))},50248:(t,n,o)=>{Promise.resolve().then(o.bind(o,88396))},71633:(t,n,o)=>{Promise.resolve().then(o.bind(o,59421)),Promise.resolve().then(o.bind(o,18331)),Promise.resolve().then(o.bind(o,9689)),Promise.resolve().then(o.bind(o,34356)),Promise.resolve().then(o.bind(o,45850)),Promise.resolve().then(o.bind(o,69082)),Promise.resolve().then(o.bind(o,6721)),Promise.resolve().then(o.bind(o,69190)),Promise.resolve().then(o.bind(o,99033)),Promise.resolve().then(o.bind(o,4300)),Promise.resolve().then(o.bind(o,59550)),Promise.resolve().then(o.t.bind(o,6286,23)),Promise.resolve().then(o.bind(o,77132))},36785:(t,n,o)=>{Promise.resolve().then(o.bind(o,90548)),Promise.resolve().then(o.bind(o,56547)),Promise.resolve().then(o.bind(o,22785)),Promise.resolve().then(o.bind(o,98972)),Promise.resolve().then(o.bind(o,779)),Promise.resolve().then(o.bind(o,53658)),Promise.resolve().then(o.bind(o,68887)),Promise.resolve().then(o.bind(o,24934)),Promise.resolve().then(o.bind(o,81681)),Promise.resolve().then(o.bind(o,64324)),Promise.resolve().then(o.bind(o,66510)),Promise.resolve().then(o.t.bind(o,91902,23)),Promise.resolve().then(o.bind(o,63980))},86696:()=>{},57192:()=>{},88396:(t,n,o)=>{"use strict";o.d(n,{default:()=>a});var e=o(54757),i=o(63679),s=o(46473),f=o(51889),l=o(68104);let a=function({className:t,dynamicPath:n}){let o=(0,i.usePathname)(),a=o.split("/");return(0,e.jsx)("nav",{"aria-label":"Хлебные крошки",children:(0,e.jsx)("div",{className:"container flex items-center justify-center",children:(0,e.jsxs)("ul",{className:(0,f.A)("inline-flex flex-wrap max-w-[768px] px-4 justify-center",t),itemScope:!0,itemType:"http://schema.org/BreadcrumbList",children:[a.map((t,n)=>{let i=function(t){switch(t){case"":return{href:"/",name:"Главная"};case"cart":return{href:"/cart",name:"Корзина"};case"offer-contract":return{href:"/offer-contract",name:"Договор оферты"};case"privacy-policy":return{href:"/privacy-policy",name:"Политика конфиденциальности"};case"contacts":return{href:"/contacts",name:"Контакты"};case"profile":return{href:"/profile",name:"Личный кабинет"};case"personal-data":return{href:"/personal-data",name:"Личные данные"};case"order-history":return{href:"/order-history",name:"История заказов"}}}(t),a=o.split("/").pop()===t,p=!!i&&!!n;return(0,e.jsxs)("li",{className:"inline-flex items-center",itemProp:"itemListElement",itemScope:!0,itemType:"http://schema.org/ListItem",children:[p&&(0,e.jsx)(l.A,{className:"mx-[6px]"}),(0,e.jsx)(s.default,{href:i?.href||"/",className:(0,f.A)({"transition hover:text-gold":!a}),itemProp:"item",children:(0,e.jsx)("span",{itemProp:"name",children:i?.name})}),(0,e.jsx)("meta",{itemProp:"position",content:n.toString()})]},n)}),n&&Array.isArray(n)&&n.map((t,o)=>{let i=a.length+o;return(0,e.jsxs)("li",{className:"inline-flex items-center text-center sm:text-left",itemProp:"itemListElement",itemScope:!0,itemType:"http://schema.org/ListItem",children:[(0,e.jsx)(l.A,{className:"mx-[6px] flex-shrink-0"}),n.length-1===o||"/catalog/sets"===t.href?(0,e.jsx)("span",{itemProp:"name",children:t.name}):(0,e.jsx)(s.default,{href:t.href,className:"transition hover:text-gold",itemProp:"item",children:(0,e.jsx)("span",{itemProp:"name",children:t.name})}),(0,e.jsx)("meta",{itemProp:"position",content:i.toString()})]},o)}),n&&!Array.isArray(n)&&(0,e.jsxs)("li",{className:"inline-flex items-center",itemProp:"itemListElement",itemScope:!0,itemType:"http://schema.org/ListItem",children:[(0,e.jsx)(l.A,{className:"mx-[6px]"}),(0,e.jsx)("span",{itemProp:"name",children:n.name}),(0,e.jsx)("meta",{itemProp:"position",content:a.length.toString()})]})]})})})}},5730:(t,n,o)=>{"use strict";o.r(n),o.d(n,{default:()=>c});var e=o(7213);o(25232);var i=o(45850),s=o(23200),f=o(74200),l=o(9689),a=o(6721),p=o(34356),r=o(65108),y=o(73987),m=o(39813),g=o(21941),h=o(19230),b=o(69082),d=o(69190);async function c({children:t}){let n=await (0,r.b)(),o=await (0,m.m)(),c=await (0,g.k)(),z=await (0,h.F)();return(0,e.jsxs)("div",{className:"relative",children:[(0,e.jsx)(i.default,{phones:c.phones,logo:o.logo}),(0,e.jsx)(y.A,{}),(0,e.jsx)(s.A,{contacts:c,logo:o.logo}),(0,e.jsx)(f.A,{categories:n,brands:z||[]}),t,(0,e.jsx)(l.default,{logo:o.logo,categories:n,contacts:c}),(0,e.jsx)(a.default,{brands:z||[]}),(0,e.jsx)(p.default,{categories:n,contacts:c}),(0,e.jsx)(b.default,{}),(0,e.jsx)(d.default,{})]})}},10938:(t,n,o)=>{"use strict";o.r(n),o.d(n,{default:()=>l,generateMetadata:()=>f});var e=o(7213);o(25232);var i=o(8079),s=o(37013);async function f(){let t=await (0,i.f)("/privacy-policy");return{title:t.title||"Политика конфиденциальности",description:t.description||"Политика конфиденциальности",keywords:t.keywords,openGraph:{title:t.og_title,description:t.og_description,url:s.$.homeUrl},alternates:{canonical:`${s.$.homeUrl}/privacy-policy`}}}async function l({children:t}){return(0,e.jsx)(e.Fragment,{children:t})}},68035:(t,n,o)=>{"use strict";o.r(n),o.d(n,{default:()=>a});var e=o(7213),i=o(39813),s=o(1908),f=o(31184);let l=`
<body lang="ru-BY" link="#0000ff" vlink="#800000" dir="ltr"><p align="justify" style="line-height: 100%; margin-bottom: 0.03in">
<font ><font ><font size="2" style="font-size: 11pt"><b>Политика
конфиденциальности</b></font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><br/>

</p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">Настоящая
Политика конфиденциальности персональных
данных (далее – Политика конфиденциальности)
действует в отношении всей информации,
которую Интернет-магази</font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="ru-RU">н
</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">balmy</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="ru-RU">.</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">by</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt">,
расположенный на доменном имени&nbsp;</font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">balmy</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="ru-RU">.</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">by</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt">,
может получить о Пользователе во время
использования сайта Интернет-магазина,
программ и продуктов Интернет-магазина.</font></font></font></p>
<ol>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Определение
	терминов</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">1.1.
В настоящей Политике конфиденциальности
используются следующие термины:</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.1.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Администрация
сайта Интернет-магазина (далее –
Администрация сайта)</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">&nbsp;–
уполномоченные сотрудники на управления
сайтом, действующие от имени </font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="ru-RU">Чимбаевича
Владислава Сергеевича</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt">,
которые организуют и (или) осуществляет
обработку персональных данных, а также
определяет цели обработки персональных
данных, состав персональных данных,
подлежащих обработке, действия (операции),
совершаемые с персональными данными.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.2.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Персональные
данные</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">&nbsp;—
любая информация, относящаяся к прямо
или косвенно определенному или
определяемому физическому лицу (субъекту
персональных данных).</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.3.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Обработка
персональных данных</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">&nbsp;—
любое действие (операция) или совокупность
действий (операций), совершаемых с
использованием средств автоматизации
или без использования таких средств с
персональными данными, включая сбор,
запись, систематизацию, накопление,
хранение, уточнение (обновление,
изменение), извлечение, использование,
передачу (распространение, предоставление,
доступ), обезличивание, блокирование,
удаление, уничтожение персональных
данных.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.4.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Конфиденциальность
персональных данных</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">&nbsp;—
обязательное для соблюдения Оператором
или иным получившим доступ к персональным
данным лицом требование не допускать
их распространения без согласия субъекта
персональных данных или наличия иного
законного основания.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.5.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Пользователь
сайта Интернет-магазина (далее
Пользователь)</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">&nbsp;–
лицо, имеющее доступ к Сайту, посредством
сети Интернет и использующее Сайт
интернет-магазина.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.6.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Cookies</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">&nbsp;—
небольшой фрагмент данных, отправленный
веб-сервером и хранимый на компьютере
пользователя, который веб-клиент или
веб-браузер каждый раз пересылает
веб-серверу в HTTP-запросе при попытке
открыть страницу соответствующего
сайта.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">1.1.7.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >IP-адрес&nbsp;</span></b></font></font></font><font ><font ><font size="2" style="font-size: 11pt">—
уникальный сетевой адрес узла в
компьютерной сети, построенной по
протоколу IP.</font></font></font></p>
<ol start="2">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Общие
	положения</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">2.1.
Использование Пользователем сайта
Интернет-магазина означает согласие с
настоящей Политикой конфиденциальности
и условиями обработки персональных
данных Пользователя.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">2.2.
В случае несогласия с условиями Политики
конфиденциальности Пользователь должен
прекратить использование сайта
Интернет-магазина.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">2.3.
Настоящая Политика конфиденциальности
применяется только к сайту Интернет-магазина</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">balmy.by</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt">.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">2.4.
Администрация сайта не проверяет
достоверность персональных данных,
предоставляемых Пользователем сайта
Интернет-магазина.</font></font></font></p>
<ol start="3">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Предмет
	политики конфиденциальности</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.1.
Настоящая Политика конфиденциальности
устанавливает обязательства Администрации
сайта интернет-магазина по неразглашению
и обеспечению режима защиты
конфиденциальности персональных данных,
которые Пользователь предоставляет по
запросу Администрации сайта при
оформлении заказа для приобретения
Товара.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.2.
Персональные данные, разрешённые к
обработке в рамках настоящей Политики
конфиденциальности, предоставляются
Пользователем путём заполнения
регистрационной формы на Сайте
интернет-магазина в разделе \xabОформление
заказа\xbb и включают в себя следующую
информацию:</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.2.1.
фамилию, имя, отчество Пользователя;</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.2.2.
контактный телефон Пользователя;</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.2.3.
адрес электронной почты (e-mail);</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.2.4.
адрес доставки Товара.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.3.
Интернет-магазин защищает Данные,
которые автоматически передаются в
процессе просмотра рекламных блоков и
при посещении страниц, на которых
установлен статистический скрипт
системы:</font></font></font></p>
<ul>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<font ><font ><font size="2" style="font-size: 11pt">IP
	адрес;</font></font></font></p>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<font ><font ><font size="2" style="font-size: 11pt">информация
	из cookies;</font></font></font></p>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<font ><font ><font size="2" style="font-size: 11pt">информация
	о браузере (или иной программе, которая
	осуществляет доступ к показу рекламы);</font></font></font></p>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<font ><font ><font size="2" style="font-size: 11pt">время
	доступа;</font></font></font></p>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<font ><font ><font size="2" style="font-size: 11pt">адрес
	страницы, на которой расположен рекламный
	блок;</font></font></font></p>
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<font ><font ><font size="2" style="font-size: 11pt">реферер
	(адрес предыдущей страницы).</font></font></font></p>
</ul>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.3.1.
Отключение cookies может повлечь невозможность
доступа к частям сайта Интернет-магазина,
требующим авторизации.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.3.2.
Интернет-магазин осуществляет сбор
статистики об IP-адресах своих посетителей.
Данная информация используется с целью
выявления и решения технических проблем,
для контроля законности проводимых
финансовых платежей.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">3.4.
Любая иная персональная информация
неоговоренная выше (история покупок,
используемые браузеры и операционные
системы и т.д.) подлежит надежному
хранению и нераспространению, за
исключением случаев, предусмотренных
в п.п. 5.2. и 5.3. настоящей Политики
конфиденциальности.</font></font></font></p>
<ol start="4">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Цели
	сбора персональной информации
	пользователя</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">4.1.
Персональные данные Пользователя
Администрация сайта интернет-магазина
может использовать в целях:</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">4.1.1.
Установления с Пользователем обратной
связи, включая направление уведомлений,
запросов, касающихся использования
Сайта интернет-магазина, оказания услуг,
обработка запросов и заявок от
Пользователя.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">4.1.2.
Подтверждения достоверности и полноты
персональных данных, предоставленных
Пользователем.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">4.1.3.
Уведомления Пользователя Сайта
интернет-магазина о состоянии Заказа.</font></font></font></p>
<ol start="5">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Способы
	и сроки обработки персональной информации</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">5.1.
Обработка персональных данных Пользователя
осуществляется без ограничения срока,
любым законным способом, в том числе в
информационных системах персональных
данных с использованием средств
автоматизации или без использования
таких средств.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">5.2.
Пользователь соглашается с тем, что
Администрация сайта вправе передавать
персональные данные третьим лицам, в
частности, курьерским службам,
организациями почтовой связи, операторам
электросвязи, исключительно в целях
выполнения заказа Пользователя,
оформленного на сайте
интернет-магазина&nbsp;</font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">balmy</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="ru-RU">.</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US">by</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt">,&nbsp;включая
&nbsp;доставку Товара.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">5.3.
Администрация сайта принимает необходимые
организационные и технические меры для
защиты персональной информации
Пользователя от неправомерного или
случайного доступа, уничтожения,
изменения, блокирования, копирования,
распространения, а также от иных
неправомерных действий третьих лиц.</font></font></font></p>
<ol start="6">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Обязательства
	сторон</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">6.1.</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >&nbsp;Пользователь
обязан:</span></b></font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">6.1.1.
Предоставить информацию о персональных
данных, необходимую для пользования
Сайтом интернет-магазина.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">6.1.2.
Обновить, дополнить предоставленную
информацию о персональных данных в
случае изменения данной информации.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">6.2.&nbsp;</font></font></font><span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Администрация
сайта обязана:</span></b></font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">6.2.1.
Использовать полученную информацию
исключительно для целей, указанных в
п. 4 настоящей Политики конфиденциальности.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">6.2.2.
Обеспечить хранение конфиденциальной
информации в тайне, не разглашать без
предварительного письменного разрешения
Пользователя, а также не осуществлять
продажу, обмен, опубликование, либо
разглашение иными возможными способами
переданных персональных данных
Пользователя, за исключением п.п. 5.2.
настоящей Политики Конфиденциальности.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">6.2.3.
Принимать меры предосторожности для
защиты конфиденциальности персональных
данных Пользователя согласно порядку,
обычно используемого для защиты такого
рода информации в существующем деловом
обороте.</font></font></font></p>
<ol start="7">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Ответственность
	сторон</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">7.1.
Администрация сайта, не исполнившая
свои обязательства, несёт ответственность
за убытки, понесённые Пользователем в
связи с неправомерным использованием
персональных данных, в соответствии с
законодательством Республики Беларусь,
за исключением случаев, предусмотренных
п.п. 5.2. и 7.2. настоящей Политики
Конфиденциальности.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">7.2.
В случае утраты или разглашения
Конфиденциальной информации Администрация
сайта не несёт ответственность, если
данная конфиденциальная информация:</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">7.2.1.
Стала публичным достоянием до её утраты
или разглашения.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">7.2.2.
Была получена от третьей стороны до
момента её получения Администрацией
сайта.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">7.2.3.
Была разглашена с согласия Пользователя.</font></font></font></p>
<ol start="8">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Разрешение
	споров</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">8.1.
До обращения в суд с иском по спорам,
возникающим из отношений между
Пользователем сайта Интернет-магазина
и Администрацией сайта, обязательным
является предъявление претензии
(письменного предложения о добровольном
урегулировании спора).</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">8.2.
Получатель претензии в течение 30
календарных дней со дня получения
претензии, письменно уведомляет заявителя
претензии о результатах рассмотрения
претензии.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">8.3.
При не достижении соглашения спор будет
передан на рассмотрение в судебный
орган в соответствии с действующим
законодательством Республики Беларусь.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">8.4.
К настоящей Политике конфиденциальности
и отношениям между Пользователем и
Администрацией сайта применяется
действующее законодательство Республики
Беларусь.</font></font></font></p>
<ol start="9">
	<li><p align="justify" style="line-height: 100%; margin-bottom: 0in">
	<span style="display: inline-block; border: none; padding: 0in"><font ><font size="2" style="font-size: 11pt"><b><font >Дополнительные
	условия</span></b></font></font></font></p>
</ol>
<p align="justify" style="line-height: 100%; margin-bottom: 0.08in"><font ><font ><font size="2" style="font-size: 11pt">9.1.
Администрация сайта вправе вносить
изменения в настоящую Политику
конфиденциальности без согласия
Пользователя.</font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><font ><font ><font size="2" style="font-size: 11pt">9.2.
Действующая Политика конфиденциальности
размещена на странице по адресу :</font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="ru-RU">
</span></font></font></font><font ><font ><font size="2" style="font-size: 11pt"><span lang="en-US"><a href="https://balmy.by/privacy-policy/">https://balmy.by/privacy-policy/</a></span></font></font></font></p>
<p align="justify" style="line-height: 100%; margin-bottom: 0in"><br/>

</p>
</body>
`,a=async function(){let t=await (0,i.m)();return(0,e.jsxs)(e.Fragment,{children:[(0,e.jsx)(f.A,{type:"h1",className:"mt-10 text-center",children:"Политика конфиденциальности"}),(0,e.jsx)(s.default,{className:"mt-4 mx-auto"}),(0,e.jsx)("div",{className:"container",children:(0,e.jsx)("div",{className:"docs mt-8 sm:mt-10 whitespace-pre-line",dangerouslySetInnerHTML:{__html:t.privacy_policy.text||l}})})]})}},1908:(t,n,o)=>{"use strict";o.d(n,{default:()=>e});let e=(0,o(13779).registerClientReference)(function(){throw Error("Attempted to call the default export of \"E:\\\\Work\\\\new-balmy\\\\components\\\\breadcrumbs.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"E:\\Work\\new-balmy\\components\\breadcrumbs.tsx","default")},31184:(t,n,o)=>{"use strict";o.d(n,{A:()=>s});var e=o(7213),i=o(48269);let s=function({children:t,className:n,type:o="h2",...s}){switch(o){case"main":return(0,e.jsx)("h1",{className:(0,i.A)("text-[30px] lg:text-[64px] font-bold leading-[1.2]",n),...s,children:t});case"h1":return(0,e.jsx)("h1",{className:(0,i.A)("text-[36px] sm:text-[52px] font-extrabold sm:font-bold",n),...s,children:t});case"h2":return(0,e.jsx)("h2",{className:(0,i.A)("text-[28px] lg:text-[52px] font-extrabold sm:font-bold",n),...s,children:t});case"h3":return(0,e.jsx)("h3",{className:(0,i.A)("text-[28px] font-extrabold sm:text-[41px] sm:font-semibold",n),...s,children:t});default:return null}}}};var n=require("../../../webpack-runtime.js");n.C(t);var o=t=>n(n.s=t),e=n.X(0,[316,626],()=>o(61646));module.exports=e})();