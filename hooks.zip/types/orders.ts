export interface IOrders {
  moysklad: {
    customer_orders: [];
    demands: [];
    total_count: number;
  };
  local: {
    individual: [];
    legal_entity: [];
  };
  total_count: number;
}
