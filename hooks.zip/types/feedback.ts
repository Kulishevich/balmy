export interface FeedbackFileds {
  phone: string;
  comment: string;
}
