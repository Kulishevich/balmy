export interface Sale {
  id: number;
  title: string;
  mainText: string;
  buttonText: string;
  buttonHref: string;
  images: string[];
}
