export interface SEO {
  created_at: string;
  description: string;
  id: number;
  keywords: string;
  name: string;
  og_description: string;
  og_title: string;
  title: string;
  updated_at: string;
}
