import {
  ICreateClientRequest,
  ILoginRequest,
  ILoginResponse,
} from "@/types/auth";

export async function CreateClientRequest(orderData: ICreateClientRequest) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/client-requests`;

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderData),
    });

    if (!res.ok) {
      const message = await res.text();
      throw new Error(`Ошибка API: ${res.status} — ${message}`);
    }

    const order = await res.text();
    return order;
  } catch (err) {
    console.error("Ошибка при отправке данных нового клиента:", err);
    throw err;
  }
}

export async function LoginRequest(
  orderData: ILoginRequest
): Promise<ILoginResponse> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/clients/login`;

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderData),
    });

    if (!res.ok) {
      const message = await res.text();
      throw new Error(`Ошибка API: ${res.status} — ${message}`);
    }

    const order = await res.json();

    return order;
  } catch (err) {
    console.error("Ошибка при входе в аккаунт:", err);
    throw err;
  }
}

export async function LogoutRequest() {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/client/logout`;

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!res.ok) {
      const message = await res.text();
      throw new Error(`Ошибка API: ${res.status} — ${message}`);
    }

    const order = await res.text();
    return order;
  } catch (err) {
    console.error("Ошибка при выходе из аккаунта:", err);
    throw err;
  }
}
