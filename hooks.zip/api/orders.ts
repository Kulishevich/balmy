import { IOrders } from "@/types/orders";

export async function getOrders() {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/api/v1/client/orders`;

  const res = await fetch(url, { next: { revalidate: 60 } });
  const clonedResponse = res.clone();

  const seo: IOrders = await clonedResponse.json();

  return seo;
}
